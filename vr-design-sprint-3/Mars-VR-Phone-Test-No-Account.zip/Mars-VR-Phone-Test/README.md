# VR Design Sprint 3 — Scene 2 and gravity control

This is a working **A-Frame 1.8.0 experience**, built on Jesse Carr's Scene 1 at commit [`cb2afbd76a7a62448dfaed5676de696201462646`](https://github.com/chbri89067-dot/VR-Design-Sprint-3/commit/cb2afbd76a7a62448dfaed5676de696201462646). It includes his complete launch followed by Brian's stratosphere-to-space transition and interactive gravity feature.

## Run locally

1. Extract the entire folder, keeping its files together.
2. With Node.js 18 or later installed, run `npm start` in this folder. On Windows, you can also double-click **Start-Scene2.cmd**. No package installation or build step is required.
3. Open **http://localhost:8080/** for Jesse's launch followed by Scene 2. To work directly on Brian's part, open **http://localhost:8080/?scene=2**.

Keep the local server running while viewing. Opening `index.html` directly can cause browser restrictions on audio and assets. A-Frame, fonts, music and sound files are bundled locally. The optional A-Frame visual inspector loads separately from its CDN when invoked.

## Interact

| Input | Action |
| --- | --- |
| Click / tap the purple **LAUNCH** button | Start Jesse's original launch once |
| Drag with the mouse / touch, or move your head in VR | Look around the existing ship |
| WASD or arrow keys | Walk around inside the cabin |
| Two-finger drag on a touch device | Move around without a keyboard; release to stop |
| In-world **GRAVITY** control or **G** | Turn gravity off / restore it during Scene 2 |
| **Q / E**, with gravity off | Lower / raise your floating height |
| **H** | Recenter your horizontal cabin position; your gravity setting stays the same |
| **V** | Enable a 1.8-second reticle dwell as an alternative to clicking |
| Supported VR controller | Point and trigger to activate a control; thumbstick to move |
| **M** | Control Brian's music and effects; Jesse's launch synthesis stays independent |

The gravity switch stays locked during launch. Once Jesse's final ascent finishes, it unlocks. Turning it off gently lifts the player and the existing cup; it does not move or resize the ship. Turning it on settles the player and cup back down. Movement and looking stay available in either state. Cabin movement is bounded to the original outer walls.

VR entry uses A-Frame's standard built-in button. A separate headset generally needs the folder served over HTTPS; a desktop can use trusted localhost. Physical-headset, Cardboard, controller and motion-comfort testing still need to be performed. Desktop controls and the actual A-Frame scene are tested, rather than a pre-rendered video.

## Project layout

```text
index.html                  Jesse's scene + Scene 2 environment, control and handoff wiring
js/scene2.js                A-Frame components: scene-two, gravity-toggle, cabin-motion,
                            follow-view, star-field, earth-surface and screen-selection
js/launch.js                Jesse's older unused file, retained unchanged; do not attach it
css/scene2.css              Existing HUD and plain audio-source link; responsive layout
assets/audio/               CC0 music/effects, source manifest and license records
vendor/                    Pinned A-Frame runtime, Roboto font assets and software licenses
credits.html                Playable per-sound source and usage page
docs/SOURCE-REVIEW.md        What was read and which parts of Jesse's scene are preserved
docs/INTEGRATION.md          Scene events and guidance for merging with the group's work
docs/TESTING.md              Checks performed and hardware limits
tests/preservation.test.mjs  Tests protecting the ship geometry and original launch script
server.mjs                  Small development server with audio-range support
```

## Scope

Scene 2 runs a 24-second visual transition, then holds the space-cruise environment so the player can explore and use gravity. It does not create or replace the group's Scenes 3–6 or window-rupture work. No camera roll or field-of-view animation is imposed. The Earth texture and stars are created in code; the Earth is stylized, not a geographic or orbital simulation.

The only new ship fixture is the gravity control on the right-hand console. Jesse's ceiling, floor, walls, pillars, railings, desk, launch control, lights, armrests and mug geometry retain their original dimensions, transforms, colors and materials. The original launch timing and synthesized engine audio are preserved. Phone mode adds only reuse of an AudioContext prepared on the setup tap, so a later gaze event can play the same sound on iOS. A new player parent separates floating movement from the ship's flight rig. The same Roboto font is served locally.

## Audio

**Space Flight** by **wipics** is listed as **CC0 / public domain** on its [original OpenGameArt page](https://opengameart.org/content/space-flight). It fades in at the Scene 2 handoff and loops quietly. The three Kenney effects are also CC0. See **credits.html**, **assets/audio/sources.json**, and the included license files for each file's origin and role. Jesse's procedural launch synthesis is preserved separately; this package does not relicense the group's code.

## Review and integrate

Run `npm test` to check the protected cabin markup and original launch script against the baseline, allowing only the documented phone AudioContext reuse expression. Read **docs/INTEGRATION.md** before merging. A separate `Scene-2-local-changes.patch` is provided beside this folder for applying the changes to the exact reviewed base. Check it against your local checkout before applying if your group has made newer edits.

## November 2 control revision

The black outlined toolbar and direction buttons have been removed. Desktop and touch clicks use A-Frame's mouse ray on the visible 3D control; VR and optional gaze use the head ray. A drag to look does not activate a console control. Keyboard shortcuts preserve audio, gravity, gaze and recenter actions, and two-finger touch movement replaces the removed direction pad. The standard A-Frame VR entry remains available. The audio-source page is reachable through a plain text link. See **docs/BUTTON-REVISION.md** and **docs/button-checks.json** for this revision's checks.

## iPhone / Cardboard-style viewer

Open **Phone headset** or add **?cardboard=1** to the URL. This adds separate eye views, phone motion permission, automatic 1.8-second gaze selection and phone-only cabin controls behind the seat. Read **docs/PHONE-TEST.md** for the HTTPS phone link and test steps. It uses the existing A-Frame scene/renderer and preserves the original ship and sound design. It is a generic stereo prototype without per-viewer QR calibration or lens correction; exact iPhone SE/iOS 26.5 hardware behavior is pending your real-device test. The setup includes a downloadable local test record.

## GitHub Pages and hands-free selection

Open **https://chbri89067-dot.github.io/vr-design-sprint-3/?cardboard=1**. The public demo and ZIP need no account. Aim the head reticle at a control for 1.8 seconds until its purple progress ring fills. All headset actions, including exit, use gaze; screen taps cannot select in-world controls during phone mode. Before inserting the phone, tap Start and allow Safari motion access. This required browser setup tap is separate from hands-free gameplay. See **docs/GITHUB-PAGES.md**.
