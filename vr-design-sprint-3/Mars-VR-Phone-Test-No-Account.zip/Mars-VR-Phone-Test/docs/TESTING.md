# Verification — November 2, 2026

Base: Jesse Carr's commit cb2afbd76a7a62448dfaed5676de696201462646. The current remote main branch was rechecked and matches this base.

## Source preservation

All five tests pass with npm test: original cabin markup/geometry/palette/materials; exact original inline launch script hash including its audio; byte-identical unloaded legacy launch.js; a single added gravity fixture using A-Frame components; and the source hashes/CC0 records for all four audio files.

## Current revision

See button-checks.json for actual Edge/Playwright browser checks. The test uses the live A-Frame renderer with real mouse clicks on the projected purple cylinder, rather than a toolbar or a synthetic launch event. It checks ignition/smoke/light, duplicate-click protection, the real ascent handoff, direct gravity-panel clicks, floating player and mug with the ship fixed, gravity restoration, mute preference, looking/WASD, keyboard recenter, gaze dwell, completion, local audio buffers/playback and the audio-credits page. Touch tests use browser touch events for the launch tap and two-finger locomotion. It also checks removal of the old toolbar/pad, mobile overflow and runtime errors.

browser-checks.json preserves the earlier October 30 verification record. Its toolbar and direction-pad checks describe the previous UI, which this revision intentionally removes.

## Hardware limits

No physical headset, tracked controllers or phone/Cardboard viewer were available. Head tracking, controller mappings, stereo comfort, frame rate, standing eye height, movement bounds and volume still need checks on the target hardware. Earlier synthetic controller-event wiring checks are not a physical-controller test. The optional A-Frame inspector may use its own CDN; normal scene assets are local.

## Cardboard-style phone revision

All five preservation checks still pass; the launch-script check permits only the prepared AudioContext expression while protecting the original synthesis and launch actions. **cardboard-phone-checks.json** records the new Edge test at an emulated SE landscape size with synthetic orientation readings: trusted-tap permission request, two eye-offset cameras on the existing renderer, orientation-driven pose, gaze launch on the primed original engine context, real launch handoff, gravity off/on, one activation per held gaze, gaze step/recenter, portrait/stale-sensor pause, exit restoration, denied-permission handling and local test records. No external requests, JS exceptions or failed HTTP responses occurred in that run. This is not an iPhone Safari or physical-headset test. **PHONE-TEST.md** contains the real-device procedure.

## GitHub and gaze-only headset selection

The current phone browser check additionally verifies that a real touch tap cannot launch in headset mode, the gaze progress ring appears, and floating-height, audio and exit controls work by gaze. Runtime files remain relative for GitHub Pages subdirectory hosting. All five original geometry/audio preservation checks still pass.
