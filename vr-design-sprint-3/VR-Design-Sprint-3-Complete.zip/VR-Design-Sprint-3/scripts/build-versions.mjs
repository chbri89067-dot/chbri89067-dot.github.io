import fs from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const source=await fs.readFile(new URL('experience.html',root),'utf8');
for(const mode of ['mobile','desktop']){
  let html=source.replace('<html lang="en">',`<html lang="en" data-experience="${mode}">`).replace('<head>','<head>\n  <base href="../">');
  if(mode==='mobile'){
    html=html.replace('<!-- PLATFORM_SCRIPTS -->','<script src="mobile/window-secret.js?v=platforms-20261104"></script>');
    html=html.replace('clear-mars-ui device-orientation','clear-mars-ui mobile-window-secret device-orientation');
    html=html.replace('<title>Earth to Mars — Complete Six-Scene Mobile VR</title>','<title>Earth to Mars — Mobile VR</title>');
  }else{
    html=html.replace('<!-- PLATFORM_SCRIPTS -->','');
    html=html.replace('scene-two cardboard-phone mars-mission','scene-two mars-mission').replace('cabin-motion mars-walk vr-menu','cabin-motion');
    html=html.replace(/^.*<script src="js\/(?:cardboard-phone|mars-walk)\.js[^\n]*\n/gm,'');
    html=html.replace(/^.*<link rel="manifest"[^\n]*\n/gm,'');
    html=html.replace(/  <a id="phone-open"[\s\S]*?(?=  <a id="audio-sources")/,'');
    html=html.replace('<title>Earth to Mars — Complete Six-Scene Mobile VR</title>','<title>Earth to Mars — Computer Version</title>');
    html=html.replace(' Touch: two-finger drag to move.','');
  }
  await fs.mkdir(new URL(mode+'/',root),{recursive:true});await fs.writeFile(new URL(mode+'/index.html',root),html);
}
console.log('Built mobile/index.html and desktop/index.html from the shared experience.');
