import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
const project=new URL('../',import.meta.url);
const read=p=>fs.readFileSync(new URL(p,project),'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const html=read('experience.html'),baseline=JSON.parse(read('tests/fixtures/baseline.json'));
test('all original cabin markup, geometry, palette and materials are preserved',()=>{
  const start=html.indexOf('      <a-entity id="spaceship-cabin">'),end=html.indexOf('      </a-entity>',start);
  let cabin=html.slice(start,end+'      </a-entity>'.length);
  cabin=cabin.replace(/\s*<!-- Brian's only new ship fixture:[\s\S]*?(?=        <!-- HERO LAUNCH BUTTON)/,'\n\n');
  cabin=cabin.replace(' id="mission-panel"','').replace(' id="mission-control-label"','').replace(' id="flight-display-label"','').replace(' id="cabin-mug"','').replaceAll(' font="vendor/fonts/Roboto-msdf.json" font-image="vendor/fonts/Roboto-msdf.png" shader="msdf"','');
  const normalize=s=>s.replace(/\s+/g,' ').trim();
  assert.equal(normalize(cabin),normalize(read('tests/fixtures/scene1-cabin.html')));
});
test('Jesse launch timing and synthesis are unchanged apart from prepared phone AudioContext reuse',()=>{
  const script=/<script>([\s\S]*?)<\/script>/.exec(html)[1].replace('window.marsPhoneAudioContext || ', '');assert.equal(sha(script),baseline.inline_launch_sha256);
});
test('older launch.js remains byte-identical and unloaded',()=>{
  assert.equal(sha(read('js/launch.js')),baseline.legacy_launch_sha256);assert(!/src=["']js\/launch\.js/.test(html));
});
test('new code is an A-Frame component extension with only one new cabin fixture',()=>{
  assert(html.includes('vendor/aframe-1.8.0.min.js'));assert(html.includes('<a-scene scene-two'));
  assert.equal((html.match(/id="gravity-btn"/g)||[]).length,1);
  const source=read('js/scene2.js');assert(source.includes("AFRAME.registerComponent('scene-two'"));assert(!source.includes('new THREE.WebGLRenderer'));
});
test('every new music/effect file matches its documented source hash and CC0 record',()=>{
  const sources=JSON.parse(read('assets/audio/sources.json'));assert.equal(sources.assets.length,4);
  for(const a of sources.assets){assert.equal(a.license,'CC0 1.0');assert.equal(sha(fs.readFileSync(new URL('assets/audio/'+a.file,project))),a.sha256);}
});
