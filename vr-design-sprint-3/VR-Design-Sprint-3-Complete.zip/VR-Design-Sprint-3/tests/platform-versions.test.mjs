import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('both generated versions preserve the shared cabin and original launch',()=>{
  const source=read('experience.html');
  const cabin=html=>html.slice(html.indexOf('      <a-entity id="spaceship-cabin">'),html.indexOf('      </a-entity>',html.indexOf('      <a-entity id="spaceship-cabin">')));
  const launch=html=>/<script>([\s\S]*?)<\/script>/.exec(html)[1];
  for(const name of ['mobile','desktop']){
    const html=read(name+'/index.html');assert.equal(cabin(html),cabin(source));assert.equal(launch(html),launch(source));assert(html.includes('<base href="../">'));
  }
});

test('mobile and computer attach only their intended platform controls',()=>{
  const mobile=read('mobile/index.html'),desktop=read('desktop/index.html');
  assert(mobile.includes('data-experience="mobile"')&&mobile.includes('clear-mars-ui mobile-window-secret'));
  assert(mobile.includes('cardboard-phone mars-mission')&&mobile.includes('mobile/window-secret.js'));
  assert(desktop.includes('data-experience="desktop"'));
  assert(!desktop.includes('mobile-window-secret')&&!desktop.includes('id="phone-setup"')&&!desktop.includes('cardboard-phone.js'));
  assert(desktop.includes('wasd-controls')&&desktop.includes('id="launch-btn"'));
});

test('a single mobile secret selection completes all four stress pulses',()=>{
  let component;
  vm.runInNewContext(read('mobile/window-secret.js'),{AFRAME:{registerComponent:(name,value)=>{component=value;}}});
  const controller={phase:'cruise',windowHits:0,crackWindow(){this.windowHits++;if(this.windowHits===4)this.phase='escaping';}};
  const instance=Object.assign({},component,{ready:true,finished:false,stressing:false,controller,el:{emit(){}},viewerUnavailable:()=>false});
  assert.equal(instance.beginStress(),true);
  for(let i=0;i<24;i++)instance.tick(i*50,50);
  assert.equal(controller.windowHits,4);assert.equal(controller.phase,'escaping');assert.equal(instance.beginStress(),false);
});

test('leaving cruise cancels a mobile stress sequence',()=>{
  let component;vm.runInNewContext(read('mobile/window-secret.js'),{AFRAME:{registerComponent:(name,value)=>{component=value;}}});
  const controller={phase:'cruise',windowHits:0,crackWindow(){this.windowHits++;}};
  const instance=Object.assign({},component,{ready:true,finished:false,stressing:false,controller,el:{emit(){}},viewerUnavailable:()=>false});
  instance.beginStress();controller.phase='approach';instance.tick(500,500);assert.equal(controller.windowHits,1);assert.equal(instance.stressing,false);
});
