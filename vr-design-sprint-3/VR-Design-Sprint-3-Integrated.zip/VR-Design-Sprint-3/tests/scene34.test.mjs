import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const project = new URL('../', import.meta.url);
const read = file => fs.readFileSync(new URL(file, project), 'utf8');

test('Scenes 3 and 4 are wired into the integrated A-Frame page and direct previews', () => {
  const html = read('index.html');
  assert.match(html, /scene-three-four/);
  assert.match(html, /src="js\/scene34\.js/);
  assert.match(html, /id="solar-system"/);
  assert.match(html, /id="ship-window"[^>]*class="clickable"/);
  assert.match(read('scene3.html'), /scene=3/);
  assert.match(read('scene4.html'), /scene=4/);
});

test('Scene 3 requires four window activations, enters zero gravity, and emits Scene 4 completion', () => {
  const controller = read('js/scene34.js');
  assert.match(controller, /this\.windowHits === 4/);
  assert.match(controller, /this\.motion\.setGravity\(false\)/);
  assert.match(controller, /this\.motion\.environment = 'space'/);
  assert.match(controller, /const CRUISE_DURATION = 14/);
  assert.match(controller, /this\.motion\.locomotionEnabled = true/);
  assert.match(controller, /this\.rig\.object3D\.position\.z -= CRUISE_SPEED \* delta/);
  assert.match(controller, /this\.phase === 'cruise'/);
  assert.match(controller, /this\.scene\.emit\('scene4-complete'/);
  assert.match(read('index.html'), /id="scene34-controller" scene-three-four/);
});

test('Scene 4 scales and advances Mars before handing off to Scene 5', () => {
  const controller = read('js/scene34.js');
  const mission = read('js/mars-mission.js');
  assert.match(controller, /this\.planet\.object3D\.scale\.setScalar\(0\.35 \+ eased \* 2\.15\)/);
  assert.match(controller, /this\.planet\.object3D\.position\.set\(0, 0, -260 \+ eased \* 160\)/);
  assert.match(mission, /this\.onScene4=\(\)=>this\.prepareLanding\(\)/);
  assert.match(mission, /SKIP ASCENT\\nHOLD \/ CLOSE EYES/);
});
