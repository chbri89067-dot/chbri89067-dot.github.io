import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('dwell timing, direction, hover, cancellation and selection logic remain exact',()=>{
  const source=read('js/scene2.js');
  const a=source.indexOf("  AFRAME.registerComponent('gaze-dwell', {"),b=source.indexOf('\n  // Use one A-Frame cursor:',a);
  const controller=source.slice(a,b)
    .replace("      this.backing=document.querySelector('#dwell-backing');\n",'')
    .replace('[[this.backing,1001],[this.outline,1002]','[[this.outline,1002]')
    .replace("          this.backing?.setAttribute('visible',false);\n",'')
    .replace("      this.backing?.setAttribute('visible',hovering);\n",'');
  const expected=JSON.parse(read('tests/fixtures/dwell-before-contrast.json')).controller_sha256;
  assert.equal(crypto.createHash('sha256').update(controller).digest('hex'),expected);
});
