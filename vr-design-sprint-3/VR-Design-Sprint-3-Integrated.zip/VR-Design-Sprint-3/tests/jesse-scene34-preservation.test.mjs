import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
const project=new URL('../',import.meta.url);
const read=p=>fs.readFileSync(new URL(p,project),'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const baseline=JSON.parse(read('tests/fixtures/jesse-scene34.json')),html=read('index.html');

test('Jesse solar-system and Mars-approach geometry, colors and dimensions stay exact',()=>{
  const world=html.slice(html.indexOf('    <a-entity id="scene34-world"'),html.indexOf('    <!-- The full Scene 2 world'));
  assert.equal(sha(world),baseline.scene34_world_sha256);
  assert.equal(sha(/<a-plane id="ship-window"[\s\S]*?<\/a-plane>/.exec(html)[0]),baseline.window_markup_sha256);
});

test('Jesse cruise, cracks, shards, escape and approach retain source behavior',()=>{
  const source=read('js/scene34.js')
    .replace("      this.window = document.querySelector('#ship-window');\n      this.window.classList.remove('clickable');","      this.window = document.querySelector('#ship-window');")
    .replaceAll('      this.flight.gravity = false;\n      this.flight.updateGravityUI();\n','');
  assert.equal(sha(source),baseline.scene34_script_sha256);
});
