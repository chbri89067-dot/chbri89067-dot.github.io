import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
const project=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,project),'utf8'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
test('all seven partner files are preserved exactly in the source reference',()=>{
  const files=JSON.parse(read('tests/fixtures/partner-files.json'));assert.equal(files.length,7);
  for(const file of files)assert.equal(sha(fs.readFileSync(new URL('reference/partner-original/'+file.path,project))),file.sha256,file.path);
});
test('the runtime landing recording is the unchanged partner MP3',()=>{
  const metadata=JSON.parse(read('assets/audio/partner-source.json')),runtime=fs.readFileSync(new URL('assets/audio/partner-liftoff.mp3',project)),original=fs.readFileSync(new URL('reference/partner-original/VR/assests/sounds/liftoff.mp3',project));
  assert.deepEqual(runtime,original);assert.equal(sha(runtime),metadata.sha256);assert.equal(metadata.license,'Not stated in package; not represented as CC0');
});
function entity(text,id){
  const start=new RegExp('<a-entity\\b[^>]*\\bid="'+id+'"[^>]*>').exec(text);assert(start,'Missing entity '+id);
  const tags=/<\/?a-entity\b[^>]*>/g;tags.lastIndex=start.index;let depth=0,token;
  while((token=tags.exec(text))){depth+=token[0].startsWith('</')?-1:1;if(depth===0)return text.slice(start.index,tags.lastIndex);}
  throw new Error('Unclosed entity '+id);
}
function geometry(text){
  const keep=new Set(['position','rotation','scale','width','height','depth','radius','radius-bottom','radius-top','color','material','animation','value']);
  return Array.from(text.matchAll(/<(a-[\w-]+)\b([^>]*)>/g),tag=>{
    const attrs={};for(const a of tag[2].matchAll(/([\w-]+)="([^"]*)"/g))if(keep.has(a[1]))attrs[a[1]]=a[2].replaceAll('#00e5ff','#38bdf8').replace(/\s+/g,' ').trim();
    return {tag:tag[1],attrs};
  });
}
test('partner habitats, landing terrain and exhaust retain their original shapes and dimensions',()=>{
  const html=read('index.html'),six=read('reference/partner-original/VR/scene6.html'),five=read('reference/partner-original/VR/scene5.html');
  for(const id of ['house1','house2','house3']){const expected=geometry(entity(six,id));assert(expected.length>=6);assert.deepEqual(geometry(entity(html,id)),expected,id);}
  assert.deepEqual(geometry(entity(html,'mars-landing-landscape')),geometry(entity(five,'mars-landscape')));
  assert.deepEqual(geometry(entity(html,'mars-landing-effects')),geometry(entity(five,'landing-effects')));
});
